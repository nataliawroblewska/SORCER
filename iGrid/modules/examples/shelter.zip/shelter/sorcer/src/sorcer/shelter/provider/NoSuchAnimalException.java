package sorcer.shelter.provider;

public class NoSuchAnimalException extends Exception {}
