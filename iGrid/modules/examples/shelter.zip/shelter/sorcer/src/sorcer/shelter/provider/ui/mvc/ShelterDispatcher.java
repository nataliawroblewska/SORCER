package sorcer.shelter.provider.ui.mvc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.logging.Logger;

import sorcer.shelter.provider.Shelter;

public class ShelterDispatcher implements ActionListener {

	private final static Logger logger = Logger
			.getLogger("sorcer.provider.shelter.ui.mvc");

	private ShelterModel model;

	private ShelterView view;

	private Shelter shelter;

	public ShelterDispatcher(ShelterModel model,ShelterView view,
			Shelter shelter) {
		this.model = model;
		this.view = view;
		this.shelter = shelter;
	}

	public void getAnimalsInShelter() {
		try {
			model.setAnimalsInShelter(shelter.getAnimalsInShelter());
		} catch (RemoteException e) {
			logger.info("Error occurred while getting animals in shelter ");
			logger.throwing(getClass().getName(), "getAnimalsInShelter", e);
		}
	}

	private void removeAnimal() {
		try {
			model.setAddAnimal(view.getAddAnimal());
			shelter.deleteAnimal(model.getRemoveAnimal());
			getAnimalsInShelter();
		} catch (Exception exception) {
			logger.info("Couldn't talk to shelter. Error was \n "
					+ exception);
			exception.printStackTrace();
		}
	}

	private void addAnimal() {
		try {
			model.setAddAnimal(view.getAddAnimal());
			shelter.addAnimal(model.getAddAnimal());
			getAnimalsInShelter();
		} catch (Exception exception) {
			logger.info("Couldn't talk to account. Error was \n "
					+ exception);
			exception.printStackTrace();
		}
	}

	public void actionPerformed(ActionEvent event) {
		String action = event.getActionCommand();
		logger.info("actionPerformed>>action: " + action);
		if (action == ShelterModel.ADD)
			addAnimal();
		else if (action == ShelterModel.REMOVE)
			removeAnimal();
	}
}
