package sorcer.shelter.provider;

public class DoubledAnimalException extends Exception {} 
