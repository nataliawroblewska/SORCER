package sorcer.shelter.provider.ui.mvc;

import java.util.Observable;

import sorcer.shelter.provider.Animal;
import java.util.*;

public class ShelterModel extends Observable {

	private LinkedList<Animal> animalsInShelter;

	private Animal removeAnimal;

	private Animal addAnimal;

	final static String ADD = " Add";

	final static String REMOVE = " Remove";

	final static String ANIMALS = "Animals";

	public ShelterModel() {
		this.animalsInShelter = new LinkedList<Animal>();
	}

	public ShelterModel(LinkedList<Animal> animalsInShelter) {
		this.animalsInShelter = animalsInShelter;
	}

	public void setAnimalsInShelter(LinkedList<Animal> animalsInShelter) {
		this.animalsInShelter = animalsInShelter;
		setChanged();
		notifyObservers(ANIMALS);
	}

	public LinkedList<Animal> getAnimalsInShelter() {
		return animalsInShelter;
	}

	public Animal getAddAnimal() {
		return addAnimal;
	}

	public void setAddAnimal(Animal addAnimal) {
		this.addAnimal = addAnimal;
		setChanged();
		notifyObservers(ADD);
	}

	public Animal getRemoveAnimal() {
		return removeAnimal;
	}

	public void setRemoveAnimal(Animal removeAnimal) {
		this.removeAnimal = removeAnimal;
		setChanged();
		notifyObservers(REMOVE);
	}
}