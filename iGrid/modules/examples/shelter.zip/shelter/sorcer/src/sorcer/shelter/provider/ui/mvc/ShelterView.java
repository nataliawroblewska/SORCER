package sorcer.shelter.provider.ui.mvc;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.net.URL;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.jini.core.lookup.ServiceItem;
import net.jini.lookup.entry.UIDescriptor;
import net.jini.lookup.ui.MainUI;
import sorcer.shelter.provider.Shelter;
import sorcer.shelter.provider.Animal;
import sorcer.core.provider.ServiceProvider;
import sorcer.ui.serviceui.UIComponentFactory;
import sorcer.ui.serviceui.UIDescriptorFactory;
import sorcer.util.Sorcer;
import javax.swing.*;
import javax.swing.DefaultListModel.*;
import java.util.*;

public class ShelterView extends JPanel implements Observer {
	
	private static final long serialVersionUID = -3812646466769297683L;

	private JList<Animal> animalsInShelterList;
	private JTextField removeTextField;
	private JTextField addTextField;
	private DefaultListModel listmodel = new DefaultListModel();

	private ShelterModel model;

	private ShelterDispatcher dispatcher;

	private final static Logger logger = Logger
			.getLogger("sorcer.provider.shelter.ui.mvc");

	public ShelterView(Object provider) {
		super();
		getAccessibleContext().setAccessibleName("ShelterView Tester");
		ServiceItem item = (ServiceItem) provider;

		if (item.service instanceof Shelter) {
			Shelter shelter = (Shelter) item.service;
			model = new ShelterModel();
			dispatcher = new ShelterDispatcher(model, this, shelter);
			createView();
			model.addObserver(this);
			dispatcher.getAnimalsInShelter();
		}
	}

	protected void createView() {
		setLayout(new BorderLayout());
		add(buildShelterPanel(), BorderLayout.CENTER);
	}

	private JPanel buildShelterPanel() {
		JPanel panel = new JPanel();
		JPanel actionPanel = new JPanel(new GridLayout(3, 3));

		actionPanel.add(new JLabel("Current Animals in shelter: "));
		animalsInShelterList = new JList<Animal>(listmodel);
		animalsInShelterList.setEnabled(false);
		actionPanel.add(animalsInShelterList);
		actionPanel.add(new JLabel(" "));

		actionPanel.add(new JLabel(" Removing from shelter"));
		removeTextField = new JTextField();
		actionPanel.add(removeTextField);
		JButton removeButton = new JButton("Do it");
		removeButton.addActionListener(dispatcher);
		actionPanel.add(removeButton);
		
		actionPanel.add(new JLabel("  Adding to shelter"));
		addTextField = new JTextField();
		actionPanel.add(addTextField);
		JButton addButton = new JButton("Do it");
		addButton.addActionListener(dispatcher);
		actionPanel.add(addButton);

		panel.add(actionPanel);
		return panel;
	}

	public Animal getAddAnimal() {
		return readTextField(addTextField);
	}

	public Animal getRemoveAnimal() {
		return readTextField(removeTextField);
	}

	public void clearAddAnimal() {
		addTextField.setText("");
	}

	public void clearRemoveAnimal() {
		removeTextField.setText("");
	}

	public void displayAnimals() {		
		LinkedList<Animal> animalsInShelterList = model.getAnimalsInShelter();
			for (Animal element : animalsInShelterList)
			{//moze sie nie repaintowac!!!
				listmodel.addElement(element);
			}
			//animalsInShelterList = new JList<Animal>(animalsInShelterList.toArray());
	}

	private Animal readTextField(JTextField animalNameField) {
        try {
            String name = animalNameField.getText().toLowerCase();
            return new Animal(name);
        } catch (Exception e) {
            logger.info("Field doesn't contain a valid value");
        }
        return null;
    }

	public void update(Observable o, Object arg) {
		logger.info("update>>arg: " + arg);
		if (arg != null) {
			if (arg.equals(ShelterModel.ADD))
				clearAddAnimal();
			else if (arg.equals(ShelterModel.REMOVE))
				clearRemoveAnimal();
			else if (arg.equals(ShelterModel.ANIMALS))
				displayAnimals();
		}
	}

	/**
	 * Returns a service UI descriptorfor this service. Usally this method is
	 * used as an entry in provider configuration files when smart proxies are
	 * deployed with a standard off the shelf {@link ServiceProvider}.
	 * 
	 * @return service UI descriptor
	 */
	public static UIDescriptor getUIDescriptor() {
		UIDescriptor uiDesc = null;
		try {
			uiDesc = UIDescriptorFactory.getUIDescriptor(MainUI.ROLE,
					new UIComponentFactory(new URL[] { new URL(Sorcer
							.getWebsterUrl()
							+ "/shelter-mvc-ui.jar") }, ShelterView.class
							.getName()));
		} catch (Exception ex) {
			logger.throwing(ShelterView.class.getName(), "getUIDescriptor", ex);
		}
		return uiDesc;
	}
}
